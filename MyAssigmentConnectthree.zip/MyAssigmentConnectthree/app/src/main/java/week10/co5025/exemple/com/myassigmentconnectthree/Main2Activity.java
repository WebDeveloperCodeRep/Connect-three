package week10.co5025.exemple.com.myassigmentconnectthree;

import android.content.Intent;
import android.os.Bundle;
import android.support.design.widget.FloatingActionButton;
import android.support.design.widget.Snackbar;
import android.support.v7.app.AppCompatActivity;
import android.support.v7.widget.Toolbar;
import android.view.View;
import android.widget.Button;

public class Main2Activity extends AppCompatActivity implements View.OnClickListener {

    Button button;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main2);

        Button butLogin = (Button) findViewById(R.id.login_button);
        butLogin.setOnClickListener(this);

        Button butNewGuest = (Button) findViewById(R.id.new_guest_button);
        butNewGuest.setOnClickListener(this);

        Button butAbout = (Button) findViewById(R.id.about_button);
        butAbout.setOnClickListener(this);

        Button butExit = (Button) findViewById(R.id.exit_button);
        butExit.setOnClickListener(this);


        Toolbar toolbar = (Toolbar) findViewById(R.id.toolbar);
        setSupportActionBar(toolbar);

        FloatingActionButton fab = (FloatingActionButton) findViewById(R.id.fab);
        fab.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Snackbar.make(view, "Replace with your own action", Snackbar.LENGTH_LONG)
                        .setAction("Action", null).show();
            }
        });
    }

    @Override
    public void onClick(View view) {

        Intent i;

        switch (view.getId()) {

            case R.id.about_button:
                i = new Intent(this, Main5Activity.class);
                startActivity(i);
                break;


            case R.id.new_guest_button:
                i = new Intent(this, Main3Activity.class);
                startActivity(i);
                break;

            case R.id.login_button:
                i = new Intent(this, Main4Activity.class);
                startActivity(i);
                break;


            case R.id.exit_button:
                finish();
                break;

        }
    }
}